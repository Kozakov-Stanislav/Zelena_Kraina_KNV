import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

export default function About() {
  return (
    <>
      <Helmet>
        <title>Про нас - Zelena Kraina KNV</title>
        <meta
          name="description"
          content="Дізнайтеся більше про компанію Zelena Kraina KNV, нашу історію, керівництво та цінності"
        />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-secondary-900 mb-4">
            Про Zelena Kraina KNV
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Ми - молода компанія з великими амбіціями та чіткою місією: забезпечувати
            наших клієнтів найякіснішими матеріалами для будівництва та ремонту
          </p>
        </motion.div>

        {/* Company History */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-secondary-900 mb-6">
            Наша історія
          </h2>
          <div className="bg-white rounded-lg shadow-md p-8">
            <p className="text-gray-600 mb-4">
              Компанія Zelena Kraina KNV була заснована 14 червня 2024 року в селі Борове
              Сарненського району Рівненської області. З самого початку ми зосередились
              на оптовій торгівлі деревиною та будівельними матеріалами.
            </p>
            <p className="text-gray-600">
              Наше розташування в одному з найбагатших на ліси регіонів України
              дозволяє нам забезпечувати клієнтів високоякісною деревиною за
              конкурентними цінами.
            </p>
          </div>
        </motion.section>

        {/* Leadership */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-secondary-900 mb-6">
            Керівництво
          </h2>
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-48 h-48 bg-gray-200 rounded-full flex items-center justify-center">
                <span className="text-gray-400">Фото</span>
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-secondary-900 mb-2">
                  Назарій Володимирович Крук
                </h3>
                <p className="text-lg text-primary-600 mb-4">Директор</p>
                <p className="text-gray-600">
                  Під керівництвом Назарія Володимировича компанія впевнено розвивається
                  та розширює свою присутність на ринку будівельних матеріалів України.
                </p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Corporate Identity */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-bold text-secondary-900 mb-6">
            Наші цінності
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-secondary-900 mb-3">
                Якість
              </h3>
              <p className="text-gray-600">
                Ми працюємо тільки з перевіреними постачальниками та гарантуємо
                якість кожного товару
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-secondary-900 mb-3">
                Надійність
              </h3>
              <p className="text-gray-600">
                Дотримуємося всіх домовленостей та термінів поставок
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-secondary-900 mb-3">
                Розвиток
              </h3>
              <p className="text-gray-600">
                Постійно розширюємо асортимент та покращуємо сервіс
              </p>
            </div>
          </div>
        </motion.section>
      </div>
    </>
  );
}