import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Mail, Download } from 'lucide-react';
import Button from '../components/UI/Button';

const categories = [
  {
    id: 'timber',
    title: 'Деревина',
    description:
      'Широкий вибір високоякісної деревини різних порід та розмірів',
    products: [
      {
        name: 'Дошка обрізна',
        image:
          'https://lvivmarket.net/static-files/img/goods/2a/7a/785_modrina-listvennitsa.jpg',
        specs: [
          'Сосна, ялина',
          'Довжина: 4-6 м',
          'Ширина: 100-200 мм',
          'Товщина: 25-50 мм',
          'Вологість: 16-18%',
        ],
      },
      {
        name: 'Брус',
        image: 'https://images.prom.ua/4635815728_w600_h600_4635815728.jpg',
        specs: [
          'Сосна, ялина',
          'Довжина: 4-6 м',
          'Перетин: 100x100 - 200x200 мм',
          'Вологість: 16-18%',
        ],
      },
    ],
  },
  {
    id: 'construction',
    title: 'Будівельні матеріали',
    description: 'Все необхідне для будівництва та ремонту',
    products: [
      {
        name: 'Цемент',
        image:
          'https://stroymat.kiev.ua/image/cache/catalog/polimin/m500-1500x1500-800x800.jpg',
        specs: [
          'Марка: М400, М500',
          'Вага: 25 кг, 50 кг',
          'Виробник: Україна',
          'Для внутрішніх та зовнішніх робіт',
        ],
      },
      {
        name: 'Цегла',
        image:
          'https://budeko.com.ua/image/cache/catalog/01-kirpich/15-pechnoj/lode/kirpich-pechnoj-m500-lode-gemini-poln-0-600x600.jpg',
        specs: [
          'Повнотіла, пустотіла',
          'Розмір: 250x120x65 мм',
          'Марка міцності: М100, М125',
          'Морозостійкість: F50',
        ],
      },
    ],
  },
  {
    id: 'sanitary',
    title: 'Сантехнічне обладнання',
    description: 'Якісна сантехніка та комплектуючі від провідних виробників',
    products: [
      {
        name: 'Змішувачі',
        image:
          'https://home-design-shop.com/wp-content/uploads/2023/12/o1cn01b2xuwt21vtivcqqud_2215043436990-0-cib.jpg',
        specs: [
          'Матеріал: латунь',
          'Покриття: хром',
          'Гарантія: 5 років',
          'Для ванної та кухні',
        ],
      },
      {
        name: 'Радіатори',
        image:
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRg6MsQLb_XHuFzIyn1ITAPRKB-z0JyQXviTw&s',
        specs: [
          'Алюмінієві, біметалеві',
          'Висота: 500-600 мм',
          'Потужність: 185 Вт/секція',
          'Гарантія: 10 років',
        ],
      },
    ],
  },
];

export default function Products() {
  return (
    <>
      <Helmet>
        <title>Продукція - Zelena Kraina KNV</title>
        <meta
          name="description"
          content="Широкий асортимент: деревина, будівельні матеріали та сантехнічне обладнання"
        />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-secondary-900 mb-4">
            Наша продукція
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Пропонуємо широкий асортимент високоякісних матеріалів для
            будівництва та ремонту
          </p>
        </motion.div>

        {/* Categories */}
        <div className="space-y-16">
          {categories.map((category, index) => (
            <motion.section
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-lg shadow-md overflow-hidden"
            >
              <div className="p-8">
                <h2 className="text-3xl font-bold text-secondary-900 mb-4">
                  {category.title}
                </h2>
                <p className="text-gray-600 mb-8">{category.description}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {category.products.map((product, productIndex) => (
                    <div
                      key={productIndex}
                      className="border rounded-lg overflow-hidden"
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-6">
                        <h3 className="text-xl font-semibold text-secondary-900 mb-3">
                          {product.name}
                        </h3>
                        <ul className="space-y-2 mb-6">
                          {product.specs.map((spec, specIndex) => (
                            <li key={specIndex} className="text-gray-600">
                              • {spec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 flex flex-wrap gap-4">
                  <Button
                    variant="primary"
                    className="flex items-center"
                    onClick={() => (window.location.href = '/contacts')}
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Надіслати запит
                  </Button>
                  <Button
                    variant="outline"
                    className="flex items-center"
                    onClick={() => alert('Прайс-лист буде доступний незабаром')}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Завантажити прайс
                  </Button>
                </div>
              </div>
            </motion.section>
          ))}
        </div>
      </div>
    </>
  );
}
