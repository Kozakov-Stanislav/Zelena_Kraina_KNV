import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { ArrowRight, Truck, Building, ShieldCheck } from 'lucide-react';
import Button from '../components/UI/Button';

const features = [
  {
    icon: <Truck className="h-6 w-6" />,
    title: 'Швидка доставка',
    description: 'Організовуємо доставку по всій території України',
  },
  {
    icon: <Building className="h-6 w-6" />,
    title: 'Великий асортимент',
    description: 'Широкий вибір деревини та будівельних матеріалів',
  },
  {
    icon: <ShieldCheck className="h-6 w-6" />,
    title: 'Гарантія якості',
    description: 'Всі матеріали сертифіковані та відповідають стандартам',
  },
];

const slides = [
  {
    id: 1,
    imageUrl:
      'https://budtex.com.ua/images/material/wood-construction-materials.jpg',
    alt: 'Високоякісна деревина',
  },
  {
    id: 2,
    imageUrl:
      'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&q=80',
    alt: 'Будівельні матеріали',
  },
  {
    id: 3,
    imageUrl: 'https://ye.ua/images/upload/ogo/1943-16057165180.jpeg',
    alt: 'Сантехнічне обладнання',
  },
];

export default function Home() {
  const [currentSlide, setCurrentSlide] = React.useState(0);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Helmet>
        <title>
          Zelena Kraina KNV - Оптова торгівля деревиною та будматеріалами
        </title>
        <meta
          name="description"
          content="Оптова торгівля деревиною, будівельними матеріалами та сантехнічним обладнанням у Рівненській області"
        />
      </Helmet>

      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden">
        {slides.map((slide, index) => (
          <motion.div
            key={slide.id}
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: index === currentSlide ? 1 : 0 }}
            transition={{ duration: 0.5 }}
          >
            <img
              src={slide.imageUrl}
              alt={slide.alt}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-50" />
          </motion.div>
        ))}

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.h1
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-8"
            >
              Оптова торгівля преміальною деревиною та будматеріалами
            </motion.h1>
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Button
                variant="primary"
                size="lg"
                onClick={() => (window.location.href = '/products')}
                className="group"
              >
                Переглянути продукцію
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Company Brief */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-secondary-900 mb-4">
              Про компанію
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Zelena Kraina KNV - ваш надійний партнер у сфері оптової торгівлі
              деревиною та будівельними матеріалами з 2024 року.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-secondary-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Готові розпочати співпрацю?
          </h2>
          <p className="text-lg text-primary-100 mb-8">
            Зв'яжіться з нами для отримання персональної консультації та
            найкращих цін
          </p>
          <Button
            variant="outline"
            size="lg"
            onClick={() => (window.location.href = '/contacts')}
            className="bg-white hover:bg-primary-50"
          >
            Зв'язатися з нами
          </Button>
        </div>
      </section>
    </>
  );
}
