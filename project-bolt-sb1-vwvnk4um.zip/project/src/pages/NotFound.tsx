import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import Button from '../components/UI/Button';

export default function NotFound() {
  return (
    <>
      <Helmet>
        <title>404 - Сторінку не знайдено | Zelena Kraina KNV</title>
      </Helmet>

      <div className="min-h-[calc(100vh-200px)] flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h1 className="text-9xl font-bold text-primary-600">404</h1>
          <h2 className="text-3xl font-semibold text-secondary-900 mt-4 mb-6">
            Сторінку не знайдено
          </h2>
          <p className="text-gray-600 mb-8">
            Вибачте, але сторінка, яку ви шукаєте, не існує або була переміщена
          </p>
          <Link to="/">
            <Button variant="primary">Повернутися на головну</Button>
          </Link>
        </motion.div>
      </div>
    </>
  );
}
