import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Plus, Edit, Trash2, Package, Search } from 'lucide-react';
import { useProducts } from '../../hooks/useProducts';
import { Product } from '../../lib/supabase';
import Button from '../../components/UI/Button';
import ProductForm from '../../components/Admin/ProductForm';

export default function ProductsManagement() {
  const { products, loading, createProduct, updateProduct, deleteProduct } = useProducts();
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formLoading, setFormLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { value: 'all', label: 'Всі категорії' },
    { value: 'timber', label: 'Деревина' },
    { value: 'construction', label: 'Будівельні матеріали' },
    { value: 'sanitary', label: 'Сантехнічне обладнання' },
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (product.description && product.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCreateProduct = async (productData: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
    setFormLoading(true);
    try {
      const { error } = await createProduct(productData);
      if (!error) {
        setShowForm(false);
      }
    } finally {
      setFormLoading(false);
    }
  };

  const handleUpdateProduct = async (productData: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
    if (!editingProduct) return;
    
    setFormLoading(true);
    try {
      const { error } = await updateProduct(editingProduct.id, productData);
      if (!error) {
        setEditingProduct(null);
        setShowForm(false);
      }
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeleteProduct = async (product: Product) => {
    if (window.confirm(`Ви впевнені, що хочете видалити "${product.name}"?`)) {
      await deleteProduct(product.id);
    }
  };

  const openEditForm = (product: Product) => {
    setEditingProduct(product);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingProduct(null);
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'timber': return 'Деревина';
      case 'construction': return 'Будівельні матеріали';
      case 'sanitary': return 'Сантехнічне обладнання';
      default: return category;
    }
  };

  return (
    <>
      <Helmet>
        <title>Управління продуктами - Адмін панель</title>
      </Helmet>

      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-secondary-900">Управління продуктами</h1>
            <p className="text-gray-600 mt-2">
              Створюйте, редагуйте та видаляйте продукти
            </p>
          </div>
          <Button
            variant="primary"
            onClick={() => setShowForm(true)}
            className="flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            Додати продукт
          </Button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Пошук продуктів..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              {categories.map(cat => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Products List */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-secondary-900">
              Продукти ({filteredProducts.length})
            </h2>
          </div>
          <div className="p-6">
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
                <p className="text-gray-500 mt-2">Завантаження...</p>
              </div>
            ) : filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <div key={product.id} className="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-full h-48 object-cover"
                      />
                    ) : (
                      <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                        <Package className="h-12 w-12 text-gray-400" />
                      </div>
                    )}
                    <div className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-secondary-900 line-clamp-2">
                          {product.name}
                        </h3>
                        <span className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full whitespace-nowrap ml-2">
                          {getCategoryLabel(product.category)}
                        </span>
                      </div>
                      {product.description && (
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {product.description}
                        </p>
                      )}
                      {product.specifications && product.specifications.length > 0 && (
                        <div className="mb-4">
                          <p className="text-xs font-medium text-gray-700 mb-1">Характеристики:</p>
                          <ul className="text-xs text-gray-600 space-y-1">
                            {product.specifications.slice(0, 3).map((spec, index) => (
                              <li key={index}>• {spec}</li>
                            ))}
                            {product.specifications.length > 3 && (
                              <li className="text-gray-400">+ ще {product.specifications.length - 3}</li>
                            )}
                          </ul>
                        </div>
                      )}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditForm(product)}
                          className="flex-1"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Редагувати
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteProduct(product)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  {searchTerm || selectedCategory !== 'all' 
                    ? 'Продукти не знайдені за вашими критеріями' 
                    : 'Продукти відсутні'
                  }
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Product Form Modal */}
      {showForm && (
        <ProductForm
          product={editingProduct}
          onSubmit={editingProduct ? handleUpdateProduct : handleCreateProduct}
          onClose={closeForm}
          loading={formLoading}
        />
      )}
    </>
  );
}