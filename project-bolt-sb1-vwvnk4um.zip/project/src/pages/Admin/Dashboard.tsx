import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Package, Users, TrendingUp, Calendar } from 'lucide-react';
import { useProducts } from '../../hooks/useProducts';

export default function AdminDashboard() {
  const { products, loading } = useProducts();

  const stats = [
    {
      name: 'Всього продуктів',
      value: products.length,
      icon: Package,
      color: 'bg-blue-500',
    },
    {
      name: 'Деревина',
      value: products.filter(p => p.category === 'timber').length,
      icon: TrendingUp,
      color: 'bg-green-500',
    },
    {
      name: 'Будматеріали',
      value: products.filter(p => p.category === 'construction').length,
      icon: Users,
      color: 'bg-yellow-500',
    },
    {
      name: 'Сантехніка',
      value: products.filter(p => p.category === 'sanitary').length,
      icon: Calendar,
      color: 'bg-purple-500',
    },
  ];

  const recentProducts = products.slice(0, 5);

  return (
    <>
      <Helmet>
        <title>Дашборд - Адмін панель</title>
      </Helmet>

      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-secondary-900">Дашборд</h1>
          <p className="text-gray-600 mt-2">
            Огляд системи управління контентом
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.name} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center">
                  <div className={`${stat.color} p-3 rounded-lg`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                    <p className="text-2xl font-bold text-secondary-900">
                      {loading ? '...' : stat.value}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Recent Products */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-secondary-900">
              Останні продукти
            </h2>
          </div>
          <div className="p-6">
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
                <p className="text-gray-500 mt-2">Завантаження...</p>
              </div>
            ) : recentProducts.length > 0 ? (
              <div className="space-y-4">
                {recentProducts.map((product) => (
                  <div key={product.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                        <Package className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold text-secondary-900">{product.name}</h3>
                      <p className="text-sm text-gray-600 capitalize">
                        {product.category === 'timber' && 'Деревина'}
                        {product.category === 'construction' && 'Будівельні матеріали'}
                        {product.category === 'sanitary' && 'Сантехнічне обладнання'}
                      </p>
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(product.created_at).toLocaleDateString('uk-UA')}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Продукти відсутні</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}