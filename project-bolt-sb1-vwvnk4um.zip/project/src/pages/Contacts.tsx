import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin } from 'lucide-react';
import Button from '../components/UI/Button';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const contactInfo = [
  {
    icon: <Phone className="h-6 w-6" />,
    title: 'Телефон',
    content: '+380 (66) 991-00-86',
    href: 'tel:+380669910086',
  },
  {
    icon: <Mail className="h-6 w-6" />,
    title: 'Email',
    content: 'kubukevicroman@gmail.com',
    href: 'mailto:kubukevicroman@gmail.com',
  },
  {
    icon: <MapPin className="h-6 w-6" />,
    title: 'Адреса',
    content:
      'вул. Ювілейна, 47, с. Борове, Сарненський район, Рівненська область',
    href: 'https://maps.app.goo.gl/WiHNsYwKAfitW2289',
  },
];

// Coordinates for Borove village, Sarny District, Rivne Oblast
const mapCenter = {
  lat: 51.33072,
  lng: 26.79983
};

export default function Contacts() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    alert(
      "Дякуємо за ваше повідомлення! Ми зв'яжемося з вами найближчим часом."
    );
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Контакти - Zelena Kraina KNV</title>
        <meta
          name="description"
          content="Зв'яжіться з Zelena Kraina KNV. Наша адреса: вул. Ювілейна, 47, с. Борове, Сарненський район, Рівненська область"
        />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-secondary-900 mb-4">
            Зв'яжіться з нами
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Маєте питання? Зв'яжіться з нами будь-яким зручним способом
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="space-y-8">
              {contactInfo.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  className="flex items-start p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600">
                    {item.icon}
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold text-secondary-900">
                      {item.title}
                    </h3>
                    <p className="text-gray-600">{item.content}</p>
                  </div>
                </a>
              ))}
            </div>

            {/* Map */}
            <div className="mt-8 h-[300px] rounded-lg overflow-hidden shadow-md">
              <LoadScript googleMapsApiKey="AIzaSyBFw0ch3HJvF_vDg3yyeKWkgQfsNke9_nk">
                <GoogleMap
                  mapContainerStyle={{ width: '100%', height: '100%' }}
                  center={mapCenter}
                  zoom={14}
                >
                  <Marker position={mapCenter} />
                </GoogleMap>
              </LoadScript>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-white rounded-lg shadow-md p-8">
              <h2 className="text-2xl font-bold text-secondary-900 mb-6">
                Надіслати повідомлення
              </h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Ім'я
                  </label>
                  <input
                    type="text"
                    id="name"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Повідомлення
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={formData.message}
                    onChange={(e) =>
                      setFormData({ ...formData, message: e.target.value })
                    }
                  />
                </div>
                <Button type="submit" variant="primary" className="w-full">
                  Надіслати
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
}