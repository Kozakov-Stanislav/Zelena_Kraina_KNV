export interface Product {
  id: string;
  name: string;
  category: 'timber' | 'construction' | 'sanitary';
  description: string;
  specifications: string[];
  imageUrl: string;
  priceListPdf?: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  message: string;
}