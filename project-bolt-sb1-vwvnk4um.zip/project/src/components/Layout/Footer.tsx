import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, TreePine } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-secondary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="flex items-center gap-2">
              <TreePine className="h-8 w-8 text-primary-500" />
              <span className="text-xl font-semibold">Zelena Kraina KNV</span>
            </Link>
            <p className="mt-4 text-gray-400">
              Оптова торгівля деревиною та будівельними матеріалами
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Швидкі посилання</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-primary-500">
                  Головна
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-primary-500">
                  Про нас
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-400 hover:text-primary-500">
                  Продукція
                </Link>
              </li>
              <li>
                <Link to="/contacts" className="text-gray-400 hover:text-primary-500">
                  Контакти
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Контакти</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary-500" />
                <a href="tel:+380669910086" className="text-gray-400 hover:text-primary-500">
                  +380 (66) 991-00-86
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary-500" />
                <a href="mailto:kubukevicroman@gmail.com" className="text-gray-400 hover:text-primary-500">
                  kubukevicroman@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-5 w-5 text-primary-500 flex-shrink-0" />
                <span className="text-gray-400">
                  вул. Ювілейна, 47, с. Борове, Сарненський район, Рівненська область
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Робочі години</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Пн-Пт: 9:00 - 18:00</li>
              <li>Сб: 9:00 - 15:00</li>
              <li>Нд: Вихідний</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800">
          <p className="text-center text-gray-400">
            © {new Date().getFullYear()} Zelena Kraina KNV. Всі права захищені.
          </p>
        </div>
      </div>
    </footer>
  );
}