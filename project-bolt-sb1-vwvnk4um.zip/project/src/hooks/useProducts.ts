import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

export interface Product {
  id: string;
  name: string;
  category: string;
  description: string | null;
  specifications: string[] | null;
  image_url: string | null;
  created_at: string;
  updated_at: string;
}

// Mock data for products
const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Дошка обрізна сосна',
    category: 'timber',
    description: 'Високоякісна обрізна дошка з сосни для будівельних робіт',
    specifications: [
      'Довжина: 4-6 м',
      'Ширина: 100-200 мм',
      'Товщина: 25-50 мм',
      'Вологість: 16-18%'
    ],
    image_url: 'https://lvivmarket.net/static-files/img/goods/2a/7a/785_modrina-listvennitsa.jpg',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Брус сосновий',
    category: 'timber',
    description: 'Брус з сосни для каркасного будівництва',
    specifications: [
      'Довжина: 4-6 м',
      'Перетин: 100x100 - 200x200 мм',
      'Вологість: 16-18%'
    ],
    image_url: 'https://images.prom.ua/4635815728_w600_h600_4635815728.jpg',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: '3',
    name: 'Цемент М500',
    category: 'construction',
    description: 'Портландцемент марки М500 для будівельних робіт',
    specifications: [
      'Марка: М500',
      'Вага: 25 кг, 50 кг',
      'Виробник: Україна',
      'Для внутрішніх та зовнішніх робіт'
    ],
    image_url: 'https://stroymat.kiev.ua/image/cache/catalog/polimin/m500-1500x1500-800x800.jpg',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
];

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Load from localStorage or use mock data
      const savedProducts = localStorage.getItem('admin_products');
      if (savedProducts) {
        setProducts(JSON.parse(savedProducts));
      } else {
        setProducts(mockProducts);
        localStorage.setItem('admin_products', JSON.stringify(mockProducts));
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Помилка завантаження продуктів');
    } finally {
      setLoading(false);
    }
  };

  const saveProducts = (updatedProducts: Product[]) => {
    localStorage.setItem('admin_products', JSON.stringify(updatedProducts));
  };

  const createProduct = async (productData: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const newProduct: Product = {
        ...productData,
        id: Date.now().toString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      
      const updatedProducts = [newProduct, ...products];
      setProducts(updatedProducts);
      saveProducts(updatedProducts);
      
      toast.success('Продукт успішно створено');
      return { data: newProduct, error: null };
    } catch (error) {
      console.error('Error creating product:', error);
      toast.error('Помилка створення продукту');
      return { data: null, error };
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const updatedProducts = products.map(p => 
        p.id === id 
          ? { ...p, ...updates, updated_at: new Date().toISOString() }
          : p
      );
      
      const updatedProduct = updatedProducts.find(p => p.id === id);
      setProducts(updatedProducts);
      saveProducts(updatedProducts);
      
      toast.success('Продукт успішно оновлено');
      return { data: updatedProduct, error: null };
    } catch (error) {
      console.error('Error updating product:', error);
      toast.error('Помилка оновлення продукту');
      return { data: null, error };
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const updatedProducts = products.filter(p => p.id !== id);
      setProducts(updatedProducts);
      saveProducts(updatedProducts);
      
      toast.success('Продукт успішно видалено');
      return { error: null };
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Помилка видалення продукту');
      return { error };
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return {
    products,
    loading,
    createProduct,
    updateProduct,
    deleteProduct,
    refetch: fetchProducts,
  };
}